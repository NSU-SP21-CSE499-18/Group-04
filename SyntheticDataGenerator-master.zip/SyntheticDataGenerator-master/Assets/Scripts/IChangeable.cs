﻿public interface IChangeable {

    void ChangeRandom();
}
